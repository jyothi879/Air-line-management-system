package airlinemanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddCustomer extends JFrame implements ActionListener{
    
     JTextField tfname,tfnation,tfaa,tfadrs,tfph;
     JRadioButton rdbfemale,rdbmale; 
    public AddCustomer(){
        
       
        
        getContentPane().setBackground(Color.white);
        setLayout(null);
        
        JLabel heading =new JLabel("ADD CUSTOMUR DETAILS");
        heading.setBounds(250,20,500,35);
        heading.setFont(new Font("Tahoma",Font.BOLD,32));
        heading.setForeground(Color.blue);
        add(heading);
        
        JLabel lblname =new JLabel("Name");
        lblname.setBounds(60,80,150,25);
        lblname.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblname);
        
        tfname=new JTextField();
        tfname.setBounds(220,80,150,25);
        add(tfname);
        
        JLabel lblnationality =new JLabel("Nationality");
        lblnationality.setBounds(60,130,150,25);
        lblnationality.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblnationality);
        
        tfnation=new JTextField();
        tfnation.setBounds(220,130,150,25);
        add(tfnation);
        
        JLabel lblaadhar =new JLabel("Aadhar Number");
        lblaadhar.setBounds(60,180,150,25);
        lblaadhar.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblaadhar);
        
        tfaa=new JTextField();
        tfaa.setBounds(220,180,150,25);
        add(tfaa);
        
        JLabel lbladrs =new JLabel("Address");
        lbladrs.setBounds(60,230,150,25);
        lbladrs.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lbladrs);
        
        tfadrs=new JTextField();
        tfadrs.setBounds(220,230,150,25);
        add(tfadrs);
        
        ButtonGroup gendergrp =new ButtonGroup();
        
        
        JLabel lblgender =new JLabel("Gender");
        lblgender.setBounds(60,280,150,25);
        lblgender.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblgender);
        
        rdbfemale=new JRadioButton("Female");
        rdbfemale.setBounds(220,280,70,25);
        rdbfemale.setBackground(Color.white);
        gendergrp.add(rdbfemale);
        add(rdbfemale);
        
        rdbmale=new JRadioButton("Male");
        rdbmale.setBounds(300,280,70,25);
        rdbmale.setBackground(Color.white);
        gendergrp.add(rdbmale);
        add(rdbmale);
        
        JLabel lblphone =new JLabel("Phone");
        lblphone.setBounds(60,330,150,25);
        lblphone.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblphone);
        
        tfph=new JTextField();
        tfph.setBounds(220,330,150,25);
        add(tfph);
        
        JButton save =new JButton("SAVE");
        save.setBackground(Color.black);
        save.setForeground(Color.white);
        save.setBounds(220,380,150,30);
        save.addActionListener(this);
        add(save);
        
        ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("airlinemanagementsystem/icons/emp.png"));
        JLabel lblimage = new JLabel(img);
        lblimage.setBounds(450,80,280,400);
        add(lblimage);
        
        setSize(900,600);
        setLocation(300,50);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        
            String name=tfname.getText();
            String nationality=tfnation.getText();
            String aadhar=tfaa.getText();
            String address=tfadrs.getText();
            String phone =tfph.getText();
            String gender =null;
            
            if (rdbmale.isSelected()){
                gender="male";
            }else{
                gender="female";
            }
            
         try{
             Conn conn =new Conn();
             String query="insert into passenger values ('"+name+"','"+nationality+"','"+phone+"','"+address+"','"+aadhar+"','"+gender+"')";
             conn.s.execute(query);
             
             JOptionPane.showMessageDialog(null, "Customer Details Added Successfully");
             
             setVisible(false);
         }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }
    public static void main(String[] args){
        new AddCustomer();
    }
}
