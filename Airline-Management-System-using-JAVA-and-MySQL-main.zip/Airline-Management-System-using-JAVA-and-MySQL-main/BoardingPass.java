package airlinemanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import com.toedter.calendar.JDateChooser;
import java.util.*;

public class BoardingPass extends JFrame implements ActionListener{
    
     JTextField tfpnr;
     JRadioButton rdbfemale,rdbmale; 
     JLabel tfname,tfnation,tfadrs,tfph,lblgender,labelfcode,labelfname,lbldate,lblsrc,lbldest;
     JButton fetchbtn,flight,bookflight;
     Choice src,dst;
     JDateChooser dcdate;
    public BoardingPass(){
        
       
        
        getContentPane().setBackground(Color.white);
        setLayout(null);
        
        JLabel heading =new JLabel("AIR INDIA");
        heading.setBounds(380,10,450,35);
        heading.setFont(new Font("Tahoma",Font.PLAIN,32));
        heading.setForeground(Color.black);
        add(heading);
        
        JLabel subheading =new JLabel("Boarding Pass");
        subheading.setBounds(360,50,300,30);
        subheading.setFont(new Font("Tahoma",Font.PLAIN,32));
        subheading.setForeground(Color.blue);
        add(subheading);
        
        
        JLabel lblaadhar =new JLabel("PNR Details");
        lblaadhar.setBounds(60,100,150,25);
        lblaadhar.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblaadhar);
        
        tfpnr=new JTextField();
        tfpnr.setBounds(220,100,150,25);
        add(tfpnr);
        
        fetchbtn=new JButton("Enter");
        fetchbtn.setBackground(Color.black);
        fetchbtn.setForeground(Color.white);
        fetchbtn.setBounds(380,100,120,25);
        fetchbtn.addActionListener(this);
        add(fetchbtn);
        
        JLabel lblname =new JLabel("NAME");
        lblname.setBounds(60,140,150,25);
        lblname.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblname);
        
        tfname=new JLabel();
        tfname.setBounds(220,140,150,25);
        add(tfname);
        
        JLabel lblnationality =new JLabel("NATIONALITY");
        lblnationality.setBounds(60,180,150,25);
        lblnationality.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblnationality);
        
        tfnation=new JLabel();
        tfnation.setBounds(220,180,150,25);
        add(tfnation);
        
      
        
        JLabel lbladrs =new JLabel("SRC");
        lbladrs.setBounds(60,220,150,25);
        lbladrs.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lbladrs);
        
        lblsrc=new JLabel();
        lblsrc.setBounds(220,220,150,25);
        add(lblsrc);
        
       
        
        
        JLabel labelgender =new JLabel("DEST");
        labelgender.setBounds(380,220,150,25);
        labelgender.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(labelgender);
        
        lbldest =new JLabel();
        lbldest.setBounds(530,220,150,25);
        add(lbldest);
       
        
        JLabel lblfname =new JLabel("Flight Name");
        lblfname.setBounds(380,260,150,25);
        lblfname.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblfname);
        
        labelfname=new JLabel();
        labelfname.setBounds(530,260,150,25);
        add(labelfname);
        
        JLabel lblfcode =new JLabel("Flight Code");
        lblfcode.setBounds(60,260,150,25);
        lblfcode.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblfcode);
        
        labelfcode=new JLabel();
        labelfcode.setBounds(220,260,150,25);
        add(labelfcode);
        
        lbldate =new JLabel("Date");
        lbldate.setBounds(60,300,150,25);
        lbldate.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lbldate);
        
        lbldate=new JLabel();
        lbldate.setBounds(220,300,150,25);
        add(lbldate);
        
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("airlinemanagementsystem/icons/airindia.png"));
        Image i2=i1.getImage().getScaledInstance(300, 230, Image.SCALE_DEFAULT);
        ImageIcon image =new ImageIcon(i2);
        JLabel lblimage = new JLabel(image);
        lblimage.setBounds(600,0,300,300);
        add(lblimage);
        
       
        setSize(1000,450);
        setLocation(150,150);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
      
            
            String pnr=tfpnr.getText();
            
         try{
             Conn conn =new Conn();
             String query="select * from  reservation where PNR ='"+pnr+"'";
             ResultSet rs=conn.s.executeQuery(query);
              if (rs.next()){
                 tfname.setText(rs.getString("name"));
                 tfnation.setText(rs.getString("nationality")); 
                 labelfcode.setText(rs.getString("f_code"));
                 labelfname.setText(rs.getString("f_name"));
                 lbldate.setText(rs.getString("date"));
                 lblsrc.setText(rs.getString("source"));
                 lbldest.setText(rs.getString("destination"));
                 
                 
             }
             
             else{
             JOptionPane.showMessageDialog(null, "Please enter correct Aadhar Number");
             }
         }
        catch(Exception e){
            e.printStackTrace();
        }
         
        
        
       
        
    }
    public static void main(String[] args){
        new BoardingPass();
    }
}
