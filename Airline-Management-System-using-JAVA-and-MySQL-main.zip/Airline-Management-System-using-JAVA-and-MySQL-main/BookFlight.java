package airlinemanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import com.toedter.calendar.JDateChooser;
import java.util.*;

public class BookFlight extends JFrame implements ActionListener{
    
     JTextField tfaa;
     JRadioButton rdbfemale,rdbmale; 
     JLabel tfname,tfnation,tfadrs,tfph,lblgender,labelfcode,labelfname,lbldate;
     JButton fetchbtn,flight,bookflight;
     Choice src,dst;
     JDateChooser dcdate;
    public BookFlight(){
        
       
        
        getContentPane().setBackground(Color.white);
        setLayout(null);
        
        JLabel heading =new JLabel("Book Flight");
        heading.setBounds(420,10,500,35);
        heading.setFont(new Font("Tahoma",Font.PLAIN,32));
        heading.setForeground(Color.blue);
        add(heading);
        
        
        
        
        JLabel lblaadhar =new JLabel("Aadhar");
        lblaadhar.setBounds(60,80,150,25);
        lblaadhar.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblaadhar);
        
        tfaa=new JTextField();
        tfaa.setBounds(220,80,150,25);
        add(tfaa);
        
        fetchbtn=new JButton("Fetch User");
        fetchbtn.setBackground(Color.black);
        fetchbtn.setForeground(Color.white);
        fetchbtn.setBounds(380,80,120,25);
        fetchbtn.addActionListener(this);
        add(fetchbtn);
        
        JLabel lblname =new JLabel("Name");
        lblname.setBounds(60,130,150,25);
        lblname.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblname);
        
        tfname=new JLabel();
        tfname.setBounds(220,130,150,25);
        add(tfname);
        
        JLabel lblnationality =new JLabel("Nationality");
        lblnationality.setBounds(60,180,150,25);
        lblnationality.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblnationality);
        
        tfnation=new JLabel();
        tfnation.setBounds(220,180,150,25);
        add(tfnation);
        
      
        
        JLabel lbladrs =new JLabel("Address");
        lbladrs.setBounds(60,230,150,25);
        lbladrs.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lbladrs);
        
        tfadrs=new JLabel();
        tfadrs.setBounds(220,230,150,25);
        add(tfadrs);
        
       
        
        
        JLabel labelgender =new JLabel("Gender");
        labelgender.setBounds(60,280,150,25);
        labelgender.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(labelgender);
        
        lblgender =new JLabel();
        lblgender.setBounds(220,280,150,25);
        add(lblgender);
       
        JLabel lblsource =new JLabel("Source");
        lblsource.setBounds(60,330,150,25);
        lblsource.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblsource);
        
        src=new Choice();
        src.setBounds(220, 330, 150, 25);
        add(src);
        
        JLabel lbldest =new JLabel("Destination");
        lbldest.setBounds(60,380,150,25);
        lbldest.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lbldest);
        
        dst=new Choice();
        dst.setBounds(220, 380, 150, 25);
        add(dst);
        
        try{
                Conn c =new Conn();
                String query="select * from flight";
                ResultSet rs=c.s.executeQuery(query);
                
                while(rs.next()){
                    src.add(rs.getString("source"));
                    dst.add(rs.getString("destination"));
                }
                
          }catch(Exception e){
                  e.printStackTrace();
                  }
        
        flight =new JButton("Fetch Flights");
        flight.setBackground(Color.black);
        flight.setForeground(Color.white);
        flight.setBounds(380,380,120,20);
        flight.addActionListener(this);
        add(flight);
        
        JLabel lblfname =new JLabel("Flight Name");
        lblfname.setBounds(60,430,150,25);
        lblfname.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblfname);
        
        labelfname=new JLabel();
        labelfname.setBounds(220,430,150,25);
        add(labelfname);
        
        JLabel lblfcode =new JLabel("Flight Code");
        lblfcode.setBounds(60,480,150,25);
        lblfcode.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lblfcode);
        
        labelfcode=new JLabel();
        labelfcode.setBounds(220,480,150,25);
        add(labelfcode);
        
        lbldate =new JLabel("Date Of Travel");
        lbldate.setBounds(60,530,150,25);
        lbldate.setFont(new Font("Tahoma",Font.PLAIN,16));
        add(lbldate);
        
        dcdate=new JDateChooser();
        dcdate.setBounds(220,530,150,25);
        add(dcdate);
        
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("airlinemanagementsystem/icons/details.jpg"));
        Image i2=i1.getImage().getScaledInstance(450, 320, Image.SCALE_DEFAULT);
        ImageIcon image =new ImageIcon(i2);
        JLabel lblimage = new JLabel(image);
        lblimage.setBounds(550,80,500,410);
        add(lblimage);
        
        bookflight =new JButton("Book Flight");
        bookflight.setBackground(Color.black);
        bookflight.setForeground(Color.white);
        bookflight.setBounds(220,580,150,22);
        bookflight.addActionListener(this);
        add(bookflight);
        
        setSize(1100,800);
        setLocation(200,20);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==fetchbtn){
            
            String aadhar=tfaa.getText();
            
         try{
             Conn conn =new Conn();
             String query="select * from  passenger where aadhar='"+aadhar+"'";
             ResultSet rs=conn.s.executeQuery(query);
             if (rs.next()){
                 tfname.setText(rs.getString("name"));
                 tfnation.setText(rs.getString("nationality"));
                 tfadrs.setText(rs.getString("address"));
                 
                 lblgender.setText(rs.getString("gender"));
             }
             
             else{
             JOptionPane.showMessageDialog(null, "Please enter correct Aadhar Number");
             }
             
         }
        catch(Exception e){
            e.printStackTrace();
        }
         
        }
        else if(ae.getSource()==flight){
            
            String from=src.getSelectedItem();
            String to=dst.getSelectedItem();
            
         try{
             Conn conn =new Conn();
             String query="select * from  flight where source='"+from+"'and destination='"+to+"'";
             ResultSet rs=conn.s.executeQuery(query);
             if (rs.next()){
                 labelfcode.setText(rs.getString("f_code"));
                 labelfname.setText(rs.getString("f_name"));
             }
             
             else{
             JOptionPane.showMessageDialog(null, "No Flights found");
             }
             
         }
        catch(Exception e){
            e.printStackTrace();
        }
         
        }
        else if(ae.getSource()==bookflight){
            Random random=new Random();
            String name = tfname.getText();
            String nation=tfnation.getText();
            String aadhar=tfaa.getText();
            String address=tfadrs.getText();
           
            String gender=lblgender.getText();
            String fcode=labelfcode.getText();
            String fname=labelfname.getText();
            String source=src.getSelectedItem();
            String dest=dst.getSelectedItem();
            String date=((JTextField)dcdate.getDateEditor().getUiComponent()).getText();
            
             try{
             Conn conn =new Conn();
             int pnr =random.nextInt(100000);
             String query="insert into reservation values('PNR-"+pnr+"','TICKET-"+random.nextInt(10000)+"','"+aadhar+"','"+name+"','"+nation+"','"+fname+"','"+fcode+"','"+source+"','"+dest+"','"+date+"')";
             conn.s.executeUpdate(query);
             
             JOptionPane.showMessageDialog(null, "Ticket Booked Successfully with PNR :  "+pnr+"");
             setVisible(false);
             
         }
        catch(Exception e){
            e.printStackTrace();
        }
        }
        
        
    }
    public static void main(String[] args){
        new BookFlight();
    }
}
