
package airlinemanagementsystem;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
public class Login extends JFrame implements ActionListener{
    JButton Submit,Reset,Close;
    JTextField tf;
    JPasswordField pwdf;
    public Login(){
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        JLabel lblusername=new JLabel("username");
        lblusername.setBounds(20,20,100,20);
        add(lblusername);
        
        tf=new JTextField();
        tf.setBounds(100, 20, 200, 20);
        add(tf);
        
        JLabel lblpassword=new JLabel("Password");
        lblpassword.setBounds(20,60,100,20);
        add(lblpassword);
        
        pwdf=new JPasswordField();
        pwdf.setBounds(100, 60, 200, 20);
        add(pwdf);
        
        Reset =new JButton("RESET");
        Reset.setBounds(30, 100, 90, 20);
        Reset.addActionListener(this);
        add(Reset);
        
        Submit =new JButton("SUBMIT");
        Submit.setBounds(150, 100, 90, 20);
        Submit.addActionListener(this);
        add(Submit);
        
        Close =new JButton("CLOSE");
        Close.setBounds(100, 140, 90, 20);
        Close.addActionListener(this); 
        add(Close);
        
        
        setSize(400,250);
        setLocation(600,250); 
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == Reset){
            tf.setText("");
            pwdf.setText("");
        }else if(ae.getSource() == Close){
            setVisible(false);
        }else if(ae.getSource()== Submit){
            String username=tf.getText();
            String password=pwdf.getText();
            
            try{
                Conn c=new Conn();
                String query="select * from login where username= '"+username+"' and password= '"+password+"'";
                ResultSet rs=c.s.executeQuery(query);
                if (rs.next()){
                    new Home();
                    setVisible(false);
                }else{
                    JOptionPane.showMessageDialog(null,"Invalid Username or Password");
                    setVisible(false);
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            
        }else{
            System.out.println("invalid Button");
        }
    }
    public static void main(String[] args){
        new Login();
    }
}
