package airlinemanagementsystem;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Home extends JFrame implements ActionListener{
    
    public Home(){
       
        setLayout(null);
        ImageIcon il =new ImageIcon(ClassLoader.getSystemResource("airlinemanagementsystem/icons/front.jpg"));
        JLabel image =new JLabel(il);
        image.setBounds(0,0,1600,800);
        add(image);
        
        JLabel heading =new JLabel("AIR INDIA WELCOMES YOU");
        heading.setBounds(500,20,400,40);
        heading.setForeground(Color.BLUE);
        heading.setFont(new Font("tahoma",Font.PLAIN,32));
        image.add(heading);
        
        JMenuBar menubar  =  new JMenuBar();
        setJMenuBar(menubar);
        
        JMenu details=new JMenu("Deatails");
        menubar.add(details);
        
        JMenuItem flightdetails = new JMenuItem("Flight Details");
        flightdetails.addActionListener(this);
        details.add(flightdetails);
        
        JMenuItem CustomerDetails = new JMenuItem("Add Customer Details");
        CustomerDetails.addActionListener(this);
        details.add(CustomerDetails);
        
        JMenuItem bookFlight = new JMenuItem("Book Flight");
        bookFlight.addActionListener(this);
        details.add(bookFlight);
        
        JMenuItem journeyDetails = new JMenuItem("Journey Details");
        journeyDetails.addActionListener(this);
        details.add(journeyDetails);
        
        JMenuItem Tktcancellation = new JMenuItem("Ticket cancellation");
        Tktcancellation.addActionListener(this);
        details.add(Tktcancellation );
        
        JMenu tkt =new JMenu("Ticket");
        menubar.add(tkt);
        
        JMenuItem boardingpass =new JMenuItem("Boarding Pass");
        boardingpass.addActionListener(this);
        tkt.add(boardingpass);
        
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
      
    }
    public void actionPerformed(ActionEvent ae){
      String text=ae.getActionCommand();
      if (text.equals("Add Customer Details")){
          new AddCustomer();
      }else if(text.equals("Flight Details")){
          new FlightInfo();
      }else if (text.equals("Book Flight")){
          new BookFlight();
      }else if (text.equals("Journey Details")){
          new JourneyDetails();
      }else if (text.equals("Ticket cancellation")){
          new Cancel();
      }else if(text.equals("Boarding Pass")){
          new BoardingPass();
      }
    }
    public static void main(String[] args){
        new Home();
    }
}

